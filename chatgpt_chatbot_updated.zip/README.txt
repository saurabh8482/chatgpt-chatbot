# ChatGPT Chatbot Website (Flask + OpenAI)

## 🔧 How to Run Locally

1. Install dependencies:
   pip install -r requirements.txt

2. Set your OpenAI API Key:
   Windows:
       set OPENAI_API_KEY=your_api_key_here
   Linux/macOS:
       export OPENAI_API_KEY=your_api_key_here

3. Start the app:
   python app.py

## 🚀 For Render Hosting

- Build Command: pip install -r requirements.txt
- Start Command: gunicorn app:app
- Add environment variable: OPENAI_API_KEY